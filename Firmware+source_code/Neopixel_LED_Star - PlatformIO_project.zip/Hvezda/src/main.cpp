#include <WS2812FX.h>
#include <OneButton.h>

#define LED_COUNT 44
#define LED_PIN PA12
#define BUTTON_PIN PA8
#define TIMER_MS 120000 // 2 minuty

int Effect = 0;             
int lastEffect = 0;
int Brightness = 50;
int listEffect[] = {0,7,8,10,11,12,15,17,18,20,25,32,33,35,39,42,47,50,52,54,55};
int numEffect = 0;
uint32_t listColor[] = {RED,GREEN,BLUE,WHITE,YELLOW,CYAN,MAGENTA,PURPLE,ORANGE,PINK};
int numColor = 0;
//int numInColor = 0;
unsigned long lastTime = 0;
unsigned long time = 0;

// Parameter 1 = number of pixels in strip
// Parameter 2 = Arduino pin number (most are valid)
// Parameter 3 = pixel type flags, add together as needed:
//   NEO_KHZ800  800 KHz bitstream (most NeoPixel products w/WS2812 LEDs)
//   NEO_KHZ400  400 KHz (classic 'v1' (not v2) FLORA pixels, WS2811 drivers)
//   NEO_GRB     Pixels are wired for GRB bitstream (most NeoPixel products)
//   NEO_RGB     Pixels are wired for RGB bitstream (v1 FLORA pixels, not v2)
//   NEO_RGBW    Pixels are wired for RGBW bitstream (NeoPixel RGBW products)
WS2812FX ws2812fx = WS2812FX(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

OneButton button = OneButton(
  BUTTON_PIN,  // Input pin for the button
  true,        // Button is active LOW
  true         // Enable internal pull-up resistor
);

void f_setEffect()
{
  Effect++;
  if (Effect > 21)
  {
    Effect = 0;
  }
}

void f_setBrightness()
{
  Brightness = Brightness + 50;
  if (Brightness > 255)
  {
    Brightness = 50;
  }
  ws2812fx.setBrightness(Brightness);
}

void f_setColor()
{
  numColor++;
  if (numColor > 9)
  {
    numColor = 0;
  }
  ws2812fx.setColor(listColor[numColor]);
  //ws2812fx.setSegment(0,  0,  44, listEffect[numEffect], listColor[numColor], 1500, false);
}

/* void f_setInColor()
{
  numInColor++;
  if (numInColor > 9)
  {
    numInColor = 0;
  }
  //ws2812fx.setColor(listColor[numColor]);
  ws2812fx.setSegment(1,  45,  60, 0, listColor[numInColor], 1500, false);
} */

void setup()
{
  ws2812fx.init();
  ws2812fx.setBrightness(Brightness);
  ws2812fx.setSpeed(1500);
  ws2812fx.setColor(CYAN);
  ws2812fx.setMode(0);
  
  // parameters: index, start, stop, mode, color, speed, reverse
  // ws2812fx.setSegment(0,  0,  44, 0, BLUE, 1500, false);
  // ws2812fx.setSegment(1, 45, 60, 0, WHITE, 1500, false);

  ws2812fx.start();

  button.attachClick(f_setEffect);
  button.attachLongPressStart(f_setBrightness);
  button.attachDoubleClick(f_setColor);
 // button.attachMultiClick(f_setInColor);
 
}

void loop()
{
  ws2812fx.service();
  button.tick();
  time = millis();
  
  if(time - lastTime > TIMER_MS && Effect == 0)
  {
    numEffect++;
    if (numEffect > 20)
    {
      numEffect = 0;
    }
    ws2812fx.setMode(listEffect[numEffect]);
    //ws2812fx.setSegment(0,  0,  44, listEffect[numEffect], listColor[numColor], 1500, false);
    lastTime = time;
  }

  if (lastEffect != Effect)
  {
    switch (Effect)
    {
     case 0: ws2812fx.setMode(0);                // zapnuté automatické přepínání efektů, protože Effect=0
             break;
     case 1: ws2812fx.setMode(0);
             break;
     case 2: ws2812fx.setMode(7);
             break;
     case 3: ws2812fx.setMode(8);
             break;
     case 4: ws2812fx.setMode(10);
             break;
     case 5: ws2812fx.setMode(11);
             break;
     case 6: ws2812fx.setMode(12);
             break;
     case 7: ws2812fx.setMode(15);
             break;
     case 8: ws2812fx.setMode(17);
             break;
     case 9: ws2812fx.setMode(18);
             break;
     case 10: ws2812fx.setMode(20);
             break;
     case 11: ws2812fx.setMode(25);
             break;
     case 12: ws2812fx.setMode(32);
             break;
     case 13: ws2812fx.setMode(33);
             break;
     case 14: ws2812fx.setMode(35);
             break;
     case 15: ws2812fx.setMode(39);
             break;
     case 16: ws2812fx.setMode(42);
             break;
     case 17: ws2812fx.setMode(47);
             break;
     case 18: ws2812fx.setMode(50);
             break;
     case 19: ws2812fx.setMode(52);
             break;
     case 20: ws2812fx.setMode(54);
             break;
     case 21: ws2812fx.setMode(55);
             break;
     }
    lastEffect = Effect;
  }
}